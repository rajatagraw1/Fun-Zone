let questions = [
    {
        numb: 1,
        question: "Who is Mr. Bean’s best friend?",
        answer: "Teddy",
        Options: [
            "Irma",
            "Teddy",
            "Mrs. Wicket",
            "Scrapper"
        ],
        
    },
    {
        numb: 2,
        question: "Rowan Atkinson has a master’s degree from Queen’s College, Oxford. In which field does he hold it?",
        answer: "Electrical Engineering",
        Options: [
            "Medicine",
            "Literature",
            "Electrical Engineering",
            "Philosophy"
        ],
        
    },
    {
        numb: 3,
        question: "In the episode 'The Curse of Mr. Bean', Mr. Bean is seen buttering his bread. What did he use to spread the butter?",
        answer: "A credit card",
        Options: [
            "A credit card",
            "His hands",
            "A fork",
            "Sword"
        ],
        
    },
    {
        numb: 4,
        question: "What was the original name of Mr. Bean?",
        answer: "Mr. White",
        Options: [
            "Mr. Black",
            "Mr. Right",
            "Mr. Bright",
            "Mr. White"
        ],
        
    },
    {
        numb: 5,
        question: "Mr. Bean wins a goldfish at a fair in episode 9 ('Mind the baby'). What does he do with it?",
        answer: "Puts it in his mouth",
        Options: [
            "Gives it to Irma",
            "Puts it in his mouth",
            "Puts it in a tank",
            "Throws it away"
        ],
        
    },
    {
        numb: 6,
        question: "When is Mr. Bean’s official birthday?",
        answer: "September 15th",
        Options: [
            "September 15th",
            "January 1st",
            "February 29th",
            "He doesn’t have one"
        ],
        
    },
    {
        numb: 7,
        question: "In the “Mr. Bean” pilot, Mr. Bean mistakenly takes the test for which subject?",
        answer: "Calculus",
        Options: [
            "Trigonometry",
            "Algebra",
            "Geometry",
            "Calculus"
        ],
        
    },
    {
        numb: 8,
        question: "What does Mr. Bean try to eat in the church?",
        answer: "A candy",
        Options: [
            "A burger",
            "A candy",
            "Ice Cream",
            "Sushi"
        ],
        
    },
    {
        numb: 9,
        question: "In which of the following James Bond films, did Rowan Atkinson appear?",
        answer: "Never Say Never Again",
        Options: [
            "Never Say Never Again",
            "Diamonds Are Forever",
            "Live and Let Die",
            "The Spy Who Loved Me"
        ],
        
    },
    {
        numb: 10,
        question: "What is the color of Mrs. Wickets’ dress in 'Mr. Bean: The Animated Series'?",
        answer: "Purple",
        Options: [
            "White",
            "Blue",
            "Purple",
            "Green"
        ],
        
    },
    
];