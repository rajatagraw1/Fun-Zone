let questions = [
    {
        numb: 1,
        question: "When is the opening ceremony of the Tokyo Olympic Games?",
        answer: "July 23rd",
        Options: [
            "July 22nd",
            "July 23rd",
            "July 24th",
            "July 25th"
        ],
        
    },
    {
        numb: 2,
        question: "What is the size of the Indian contingent at the Tokyo Olympics 2020?",
        answer: "228",
        Options: [
            "228",
            "336",
            "248",
            "196"
        ],
        
    },
    {
        numb: 3,
        question: "Which among the following badminton player failed to qualify for the Tokyo Olympics?",
        answer: "Saina Nehwal",
        Options: [
            "Saina Nehwal",
            "PV Sindhu",
            "B Sai Praneeth",
            "Chirag Shetty"
        ],
        
    },
    {
        numb: 4,
        question: "Who is the first and only Indian female wrestler to win a medal at the Olympics?",
        answer: "Sakshi Malik",
        Options: [
            "Vinesh Phogat",
            "Anshu Malik",
            "Sonam Malik",
            "Sakshi Malik"
        ],
        
    },
    {
        numb: 5,
        question: "Which among the following tennis players will not be playing at the Tokyo Olympics?",
        answer: "Rohan Bopanna",
        Options: [
            "Rohan Bopanna",
            "Sania Mirza",
            "Ankita Raina",
            "Sumit Nagpal"
        ],
        
    },
    {
        numb: 6,
        question: "Who will be representing India in the Women’s Artistic event?",
        answer: "Pranati Nayak",
        Options: [
            "Annu Rani",
            "Maana Patel",
            "Pranati Nayak",
            "Priyanka Goswami"
        ],
        
    },
    {
        numb: 7,
        question: "How many Indian track and field athletes have qualified for Tokyo Olympics 2020?",
        answer: "26",
        Options: [
            "32",
            "40",
            "26",
            "15"
        ],
        
    },
    {
        numb: 8,
        question: "Which Indian track and field athlete missed out on qualification in the Tokyo Olympics 2020?",
        answer: "Hima Das",
        Options: [
            "Dutee Chand",
            "Hima Das",
            "Seema Punia",
            "Kamalpreet Kaur"
        ],
        
    },
    {
        numb: 9,
        question: "Which among the following sports will make its debut at Olympics 2020?",
        answer: "Karate",
        Options: [
            "Karate",
            "Fencing",
            "Judo",
            "Equestrian"
        ],
        
    },
    {
        numb: 10,
        question: "Which sports will be returning to the Olympics this year after being cut out previously?",
        answer: "Baseball",
        Options: [
            "Baseball",
            "Golf",
            "Judo",
            "Fencing"
        ],
        
    },
    
];