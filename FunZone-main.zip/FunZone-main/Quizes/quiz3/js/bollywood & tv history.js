let questions = [
    {
        numb: 1,
        question: "First programme telecast on Doordarshan is ________",
        answer: "Krishi Darshan",
        Options: [
            "Krishi Darshan",
            "Asian games",
            "Chitrahaar",
            "Shaktimaan"
        ],
        
    },
    {
        numb: 2,
        question: "First sponsored programme telecast on Doordarshan is ________",
        answer: "Sarab Sanji Gurbani",
        Options: [
            "Hum Log",
            "Buniyaad",
            "Ramayan",
            "Sarab Sanji Gurbani"
        ],
        
    },
    {
        numb: 3,
        question: "Which bollywood film with highest number of songs?",
        answer: "Indra Sabha",
        Options: [
            "Neel Kamal",
            "Indra Sabha",
            "Alam Ara",
            "Kishan Kanaya"
        ],
        
    },
    {
        numb: 4,
        question: "First televison show that complete 1000 episodes",
        answer: "Ek Mahal Ho Sapno Ka",
        Options: [
            "Kahaani Ghar Ghar Kii",
            "Kkusum",
            "Kasautii Zindagii Kay",
            "Ek Mahal Ho Sapno Ka"
        ],
        
    },
    {
        numb: 5,
        question: "Which one is the first Bollywood film of Sridevi?",
        answer: "Solva Sawan",
        Options: [
            "Solva Sawan",
            "Julie",
            "Sadma",
            "Himmatwala"
        ],
        
    },
    {
        numb: 6,
        question: "Which one is the first film of Amitabh Bachchan's career",
        answer: "Saat Hindustani",
        Options: [
            "Parwaana",
            "Saat Hindustani",
            "Guddi",
            "Anand"
        ],
        
    },
    {
        numb: 7,
        question: "First Indian movie submitted for Oscar",
        answer: "Mother India",
        Options: [
            "Madhumati",
            "The Guide",
            "Mother India",
            "Amrapali"
        ],
        
    },
    {
        numb: 8,
        question: "First Indian sound film was",
        answer: "Alam Ara",
        Options: [
            "Amrapali",
            "Raja Harishchandra",
            "Kishan Kanya",
            "Alam Ara"
        ],
        
    },
    {
        numb: 9,
        question: "First Indian to win an Oscar award",
        answer: "Bhanu Athaiya",
        Options: [
            "Bhanu Athaiya",
            "Rasul Pookutty",
            "AR Rahman",
            "None of the Above"
        ],
        
    },
    {
        numb: 10,
        question: "First 3D animated film from India is",
        answer: "Roadside Romeo",
        Options: [
            "Ghayab Aaya",
            "Bal Ganesh",
            "Roadside Romeo",
            "Jumbo"
        ],
        
    },
    
];