let questions = [
    {
        numb: 1,
        question: "who sends Doraemon back to the past to look after Nobita ?",
        answer: "Sewashi",
        Options: [
            "Dorami",
            "Sewashi",
            "Time Travel Agency",
            "Future Nobita"
        ],
        
    },
    {
        numb: 2,
        question: "In nobita's dream he will marry whom?",
        answer: "Shizuka",
        Options: [
            "Shizuka",
            "Dorami",
            "Michan",
            "Miyoko"
        ],
        
    },
    {
        numb: 3,
        question: "What is doraemon's father name?",
        answer: "none of these",
        Options: [
            "Nobi-robe",
            "nobi-wobi",
            "nobitaku",
            "none of these"
        ],
        
    },
    {
        numb: 4,
        question: "What is the name of Doraemon,s Sister?",
        answer: "Dorami",
        Options: [
            "Dorami",
            "Shizuka",
            "Michan",
            "Dora"
        ],
        
    },
    {
        numb: 5,
        question: "In which country nobita and his friends are living?",
        answer: "tokyo",
        Options: [
            "Kyoto",
            "Shanghai",
            "kasukabe",
            "tokyo"
        ],
        
    },
    {
        numb: 6,
        question: " In movie steel troops who controlled the robot?",
        answer: "Pippo",
        Options: [
            "Time Travel Agency",
            "Chimpo",
            "Pippo",
            "Nobita"
        ],
        
    },
    {
        numb: 7,
        question: "Who was Sewashi?",
        answer: "Nobita's Grandson",
        Options: [
            "Nobita's Son",
            "Nobita's Grandson",
            "Doraemon's Friend",
            "Future Robot"
        ],
        
    },
    {
        numb: 8,
        question: "Which talent suits Nobita?",
        answer: "Shooting",
        Options: [
            "Swimming",
            "Singing",
            "Shooting",
            "Cooking"
        ],
        
    },
    {
        numb: 9,
        question: "Which is Doraemon's Favorite food?",
        answer: "Bean-Jam Bun",
        Options: [
            "Bean-Jam Bun",
            "Hotcake",
            "Koroke",
            "Doraballs"
        ],
        
    },
    {
        numb: 10,
        question: "From which centuary does Doraemon came?",
        answer: "22",
        Options: [
            "22",
            "21",
            "27",
            "23"
        ],
        
    },
    
];