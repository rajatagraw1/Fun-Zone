let questions = [
    {
        numb: 1,
        question: "From which shop Harry Potter used to buy Wands?",
        answer: "Ollivanders",
        Options: [
            "Witcher's Wands",
            "Weasleys",
            "Ollivanders",
            "Hogs-Wands"
        ],
        
    },
    {
        numb: 2,
        question: "What is the name of Harry's first Broom?",
        answer: "Nimbus 2000",
        Options: [
            "Nimbus 2000",
            "Nimbus 2001",
            "Thunderbird",
            "Firebolt"
        ],
        
    },
    {
        numb: 3,
        question: "What is the name of Harry's owl?",
        answer: "Hedwig",
        Options: [
            "Creture",
            "Hedwig",
            "Scrabbers",
            "Fluffy The Owl"
        ],
        
    },
    {
        numb: 4,
        question: "Who Warned Harry about the reopening of Chamber of Secrets?",
        answer: "Dobby",
        Options: [
            "Dumbledore",
            "Creture",
            "Alastor Moody",
            "Dobby"
        ],
        
    },
    {
        numb: 5,
        question: "Dobby used to serve _______",
        answer: "Malfoy Family",
        Options: [
            "Malfoy Family",
            "Weasley Family",
            "Prof. Dumbledore",
            "Lord Voldemort"
        ],
        
    },
    {
        numb: 6,
        question: "Who was the god father of Harry?",
        answer: "Sirius Black",
        Options: [
            "Sirius Black",
            "Prof. Dumbledore",
            "Prof. Snape",
            "Rubeus Hagrid"
        ],
        
    },
    {
        numb: 7,
        question: "What is the name of Harry's second Broom?",
        answer: "Firebolt",
        Options: [
            "Nimbus 2000",
            "Nimbus 2001",
            "Thunderbird",
            "Firebolt"
        ],
        
    },
    {
        numb: 8,
        question: "Who was Scabbers in actual?",
        answer: "Peter Pettigrew",
        Options: [
            "Ron's Mouse",
            "Peter Pettigrew",
            "Sirius Black",
            "Tom Riddle"
        ],
        
    },
    {
        numb: 9,
        question: "Which is the flying car of Arthur Weasley?",
        answer: "Ford Anglia",
        Options: [
            "Ford Angela",
            "Ford Fly",
            "Ford Anglia",
            "The Arther's Ride"
        ],
        
    },
    {
        numb: 10,
        question: "Alder Wand Wood belongs to ___________",
        answer: "Quirinus Quirrell",
        Options: [
            "Quirinus Quirrell",
            "Harry Potter",
            "Albus Dumbledore",
            "Lord Voldemort"
        ],
        
    },
    
];